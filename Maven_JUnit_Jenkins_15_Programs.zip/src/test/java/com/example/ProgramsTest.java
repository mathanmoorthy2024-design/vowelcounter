package com.example;

import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;

public class ProgramsTest {

    @Test public void q1_addsTwoNumbers() {
        assertEquals(30, Programs.add(10, 20));
    }

    @Test public void q2_checksEvenAndOdd() {
        assertEquals("Even", Programs.evenOrOdd(8));
        assertEquals("Odd", Programs.evenOrOdd(7));
    }

    @Test public void q3_findsLargestOfThree() {
        assertEquals(25, Programs.largestOfThree(10, 25, 15));
    }

    @Test public void q4_calculatesFactorial() {
        assertEquals(120L, Programs.factorial(5));
        assertEquals(1L, Programs.factorial(0));
    }

    @Test public void q5_checksPrime() {
        assertTrue(Programs.isPrime(7));
        assertFalse(Programs.isPrime(1));
        assertFalse(Programs.isPrime(9));
    }

    @Test public void q6_generatesFibonacciSeries() {
        assertEquals(Arrays.asList(0, 1, 1, 2, 3, 5), Programs.fibonacci(6));
    }

    @Test public void q7_reversesNumber() {
        assertEquals(4321, Programs.reverseNumber(1234));
    }

    @Test public void q8_checksNumberPalindrome() {
        assertTrue(Programs.isNumberPalindrome(121));
        assertFalse(Programs.isNumberPalindrome(123));
    }

    @Test public void q9_calculatesSimpleInterest() {
        assertEquals(100.0, Programs.simpleInterest(1000, 5, 2), 0.0001);
    }

    @Test public void q10_assignsGrade() {
        assertEquals("B", Programs.grade(85));
        assertEquals("A", Programs.grade(95));
        assertEquals("F", Programs.grade(45));
    }

    @Test public void q11_sumsArray() {
        assertEquals(10, Programs.sumArray(new int[]{1, 2, 3, 4}));
    }

    @Test public void q12_findsMaximumArrayElement() {
        assertEquals(9, Programs.maxArray(new int[]{3, 9, 2, 7}));
    }

    @Test public void q13_countsVowels() {
        assertEquals(2, Programs.countVowels("hello"));
    }

    @Test public void q14_reversesString() {
        assertEquals("avaj", Programs.reverseString("java"));
    }

    @Test public void q15_checksStringPalindrome() {
        assertTrue(Programs.isStringPalindrome("madam"));
        assertFalse(Programs.isStringPalindrome("hello"));
    }
}
