package com.example;

/**
 * Main entry point. Run any of the 15 lab examples by changing the
 * method calls in main, or run the JUnit tests with: mvn clean test.
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Q1 Add: " + Programs.add(10, 20));
        System.out.println("Q2 Even/Odd (8): " + Programs.evenOrOdd(8));
        System.out.println("Q3 Largest: " + Programs.largestOfThree(10, 25, 15));
        System.out.println("Q4 Factorial (5): " + Programs.factorial(5));
        System.out.println("Q5 Prime (7): " + Programs.isPrime(7));
        System.out.println("Q6 Fibonacci (6 terms): " + Programs.fibonacci(6));
        System.out.println("Q7 Reverse number (1234): " + Programs.reverseNumber(1234));
        System.out.println("Q8 Number palindrome (121): " + Programs.isNumberPalindrome(121));
        System.out.println("Q9 Simple interest: " + Programs.simpleInterest(1000, 5, 2));
        System.out.println("Q10 Grade (85): " + Programs.grade(85));
        System.out.println("Q11 Array sum: " + Programs.sumArray(new int[]{1, 2, 3, 4}));
        System.out.println("Q12 Array max: " + Programs.maxArray(new int[]{3, 9, 2, 7}));
        System.out.println("Q13 Vowels in hello: " + Programs.countVowels("hello"));
        System.out.println("Q14 Reverse string: " + Programs.reverseString("java"));
        System.out.println("Q15 String palindrome (madam): " + Programs.isStringPalindrome("madam"));
    }
}
