package com.example;

import java.util.ArrayList;
import java.util.List;

public final class Programs {
    private Programs() {}

    // Q1. Add two numbers
    public static int add(int a, int b) {
        return a + b;
    }

    // Q2. Check even or odd
    public static String evenOrOdd(int n) {
        return n % 2 == 0 ? "Even" : "Odd";
    }

    // Q3. Largest of three numbers
    public static int largestOfThree(int a, int b, int c) {
        return Math.max(a, Math.max(b, c));
    }

    // Q4. Factorial (valid input: n >= 0)
    public static long factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("n must be >= 0");
        long result = 1;
        for (int i = 2; i <= n; i++) result *= i;
        return result;
    }

    // Q5. Prime number
    public static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i <= n / i; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    // Q6. Fibonacci series: first count terms, starting 0, 1
    public static List<Integer> fibonacci(int count) {
        if (count < 0) throw new IllegalArgumentException("count must be >= 0");
        List<Integer> values = new ArrayList<Integer>();
        int a = 0, b = 1;
        for (int i = 0; i < count; i++) {
            values.add(a);
            int next = a + b;
            a = b;
            b = next;
        }
        return values;
    }

    // Q7. Reverse a non-negative number
    public static int reverseNumber(int n) {
        if (n < 0) throw new IllegalArgumentException("n must be >= 0");
        int reversed = 0;
        while (n > 0) {
            reversed = reversed * 10 + n % 10;
            n /= 10;
        }
        return reversed;
    }

    // Q8. Number palindrome
    public static boolean isNumberPalindrome(int n) {
        if (n < 0) return false;
        return n == reverseNumber(n);
    }

    // Q9. Simple interest = principal * rate * time / 100
    public static double simpleInterest(double principal, double rate, double time) {
        return principal * rate * time / 100.0;
    }

    // Q10. Grade boundaries are assumed because the supplied question does not specify them:
    // >=90 A, >=80 B, >=70 C, >=60 D, otherwise F. Marks must be 0..100.
    public static String grade(int marks) {
        if (marks < 0 || marks > 100) throw new IllegalArgumentException("marks must be 0..100");
        if (marks >= 90) return "A";
        if (marks >= 80) return "B";
        if (marks >= 70) return "C";
        if (marks >= 60) return "D";
        return "F";
    }

    // Q11. Sum of array elements
    public static int sumArray(int[] values) {
        if (values == null || values.length == 0) throw new IllegalArgumentException("array must not be empty");
        int sum = 0;
        for (int value : values) sum += value;
        return sum;
    }

    // Q12. Maximum element in array
    public static int maxArray(int[] values) {
        if (values == null || values.length == 0) throw new IllegalArgumentException("array must not be empty");
        int max = values[0];
        for (int value : values) if (value > max) max = value;
        return max;
    }

    // Q13. Count vowels (case-insensitive English vowels)
    public static int countVowels(String text) {
        if (text == null) throw new IllegalArgumentException("text must not be null");
        int count = 0;
        for (char c : text.toLowerCase().toCharArray()) {
            if ("aeiou".indexOf(c) >= 0) count++;
        }
        return count;
    }

    // Q14. Reverse a string
    public static String reverseString(String text) {
        if (text == null) throw new IllegalArgumentException("text must not be null");
        return new StringBuilder(text).reverse().toString();
    }

    // Q15. String palindrome (ignores case, but not spaces or punctuation)
    public static boolean isStringPalindrome(String text) {
        if (text == null) throw new IllegalArgumentException("text must not be null");
        return text.equalsIgnoreCase(reverseString(text));
    }
}
