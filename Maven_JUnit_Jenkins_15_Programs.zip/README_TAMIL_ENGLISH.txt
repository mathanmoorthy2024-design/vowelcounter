MAVEN + JUNIT + JENKINS: 15 LAB PROGRAMS

PROJECT REQUIREMENTS
- Java installed
- Maven installed
- Jenkins installed and running for the Jenkins part
- Internet access for Maven to download dependencies on first build

RUN IN WINDOWS POWERSHELL
1. Extract this ZIP.
2. Open PowerShell in the extracted folder (the folder containing pom.xml).
3. Check:
   java -version
   mvn -version
4. Run the JUnit tests:
   mvn clean test
5. Run all example outputs:
   mvn exec:java -Dexec.mainClass="com.example.App" -Dexec.classpathScope=runtime

EXPECTED TEST RESULT
- 15 JUnit test methods should pass.
- Maven output should end with BUILD SUCCESS.
- Test reports are in target/surefire-reports/.

JENKINS: SIMPLE FREESTYLE METHOD
1. Ensure Jenkins can access this extracted project folder.
2. Jenkins dashboard -> Manage Jenkins -> Tools.
3. Configure a Maven installation named exactly Maven3, or change Jenkinsfile to your configured name.
4. New Item -> choose Freestyle project -> OK.
5. In Build Steps:
   - Windows Jenkins: use "Execute Windows batch command" and run:
     cd /d C:\path\to\maven-junit-15-programs
     mvn clean test
   - Linux Jenkins: use "Execute shell" and run:
     cd /path/to/maven-junit-15-programs
     mvn clean test
6. Save -> Build Now -> open build number -> Console Output.
7. Confirm "BUILD SUCCESS" and test summary with zero failures.

JENKINSFILE NOTE
- Jenkinsfile is for a Pipeline job and assumes a Maven tool installation named Maven3.
- The included Jenkinsfile uses "sh", so it is for a Linux/Unix Jenkins agent.
- For Windows agents, replace sh 'mvn clean test' with bat 'mvn clean test'.
- For a real team/remote Jenkins setup, push the folder to a Git repository and configure Pipeline SCM checkout. A local path on your laptop is not automatically accessible to a remote Jenkins server.

QUESTION 10 ASSUMPTION
The supplied question sheet does not give grade boundaries. This example assumes:
A: 90-100, B: 80-89, C: 70-79, D: 60-69, F: below 60.
Use your lecturer's grading rules if different.

QUESTION 7 ASSUMPTION
Reverse-number example accepts non-negative integers only.
